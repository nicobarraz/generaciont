<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "timesheet_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Procesar registro
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $rol = $_POST['rol'];

    // Verificar si ya existe el email
    $check = $conn->prepare("SELECT email FROM users WHERE email=?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $mensaje = "<div class='error'>❌ Ya existe un usuario con ese correo.</div>";
    } else {
        $sql = "INSERT INTO users (nombre, email, password, rol) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $nombre, $email, $pass, $rol);

        if ($stmt->execute()) {
            $mensaje = "<div class='success'>✅ Usuario registrado correctamente. <a href='login.php'>Iniciar sesión</a></div>";
        } else {
            $mensaje = "<div class='error'>❌ Error: " . $conn->error . "</div>";
        }

        $stmt->close();
    }
    $check->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Registro de Usuario</h2>

        <?php if(isset($mensaje)) echo $mensaje; ?>

        <form method="POST">
            <label>Nombre:</label>
            <input type="text" name="nombre" required>

            <label>Email:</label>
            <input type="email" name="email" required>

            <label>Contraseña:</label>
            <input type="password" name="password" required>

            <label>Rol:</label>
            <select name="rol" required>
                <option value="empleado">Empleado</option>
                <option value="admin">Administrador</option>
            </select>

            <button type="submit">Registrar</button>
        </form>

        <p>¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a></p>
    </div>
</body>
</html>
