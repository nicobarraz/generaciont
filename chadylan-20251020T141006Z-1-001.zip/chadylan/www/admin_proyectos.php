<?php
session_start();
if (!isset($_SESSION['id_user']) || $_SESSION['rol'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "timesheet_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$mensaje = "";

// Agregar nuevo proyecto
if (isset($_POST['agregar'])) {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];

    $stmt = $conn->prepare("INSERT INTO projects (nombre, descripcion) VALUES (?, ?)");
    $stmt->bind_param("ss", $nombre, $descripcion);

    if ($stmt->execute()) {
        $mensaje = "<div class='success'>✅ Proyecto agregado correctamente.</div>";
    } else {
        $mensaje = "<div class='error'>❌ Error: " . $conn->error . "</div>";
    }
    $stmt->close();
}

// Eliminar proyecto
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $stmt = $conn->prepare("DELETE FROM projects WHERE id_project=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    $mensaje = "<div class='success'>✅ Proyecto eliminado.</div>";
}

// Obtener todos los proyectos
$result = $conn->query("SELECT * FROM projects ORDER BY id_project ASC");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Administrar Proyectos</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        .card {
            background: white;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.1);
            max-width: 800px;
            margin: 40px auto;
        }
        .card h2 {
            text-align: center;
            margin-bottom: 25px;
            letter-spacing: 0.5px;
        }
        form label {
            display: block;
            margin-top: 15px;
            font-weight: 500;
        }
        form input, form textarea {
            width: 100%;
            padding: 12px;
            margin-top: 5px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-family: inherit;
            font-size: 14px;
        }
        form button {
            margin-top: 20px;
            padding: 12px;
            width: 100%;
            font-size: 16px;
        }
        table {
            width: 100%;
            margin-top: 25px;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .btn-accion {
            padding: 6px 12px;
            border-radius: 8px;
            text-decoration: none;
            color: white;
            background-color: #f44336;
            font-weight: 500;
        }
        .btn-accion:hover {
            background-color: #d32f2f;
        }
        .volver {
            display: block;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="card">
        <h2>⚙️ Administrar Proyectos</h2>

        <?php if($mensaje) echo $mensaje; ?>

        <!-- Formulario para agregar proyecto -->
        <form method="POST">
            <label>Nombre del Proyecto:</label>
            <input type="text" name="nombre" required>

            <label>Descripción:</label>
            <textarea name="descripcion" rows="3"></textarea>

            <button type="submit" name="agregar">Agregar Proyecto</button>
        </form>

        <!-- Tabla de proyectos -->
        <table>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Acciones</th>
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id_project'] ?></td>
                <td><?= htmlspecialchars($row['nombre']) ?></td>
                <td><?= htmlspecialchars($row['descripcion']) ?></td>
                <td>
                    <a href="admin_proyectos.php?eliminar=<?= $row['id_project'] ?>" class="btn-accion" onclick="return confirm('¿Eliminar este proyecto?')">Eliminar</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>

        <a href="panel.php" class="volver">⬅ Volver al Panel</a>
    </div>
</body>
</html>
