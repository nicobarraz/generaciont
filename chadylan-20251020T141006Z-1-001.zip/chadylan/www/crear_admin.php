<?php
// Configuración de base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "timesheet_db";

// Conectar a MySQL
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Datos del admin
$nombre = "Administrador";
$email = "admin@correo.com"; // Cambialo a tu correo
$pass = password_hash("TuContraseñaSegura", PASSWORD_DEFAULT); // Cambia la contraseña
$rol = "admin";

// Verificar si ya existe el correo
$check = $conn->prepare("SELECT email FROM users WHERE email=?");
$check->bind_param("s", $email);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    echo "❌ Ya existe un usuario con ese correo.";
} else {
    // Insertar usuario admin
    $sql = "INSERT INTO users (nombre, email, password, rol) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $nombre, $email, $pass, $rol);

    if ($stmt->execute()) {
        echo "✅ Usuario administrador creado correctamente.";
    } else {
        echo "❌ Error: " . $conn->error;
    }

    $stmt->close();
}

$check->close();
$conn->close();
?>
