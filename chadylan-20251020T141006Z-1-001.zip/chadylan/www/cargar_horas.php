<?php
session_start();
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "timesheet_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$mensaje = "";

// Procesar carga de horas
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_user = $_SESSION['id_user'];
    $id_project = $_POST['id_project'];
    $fecha = $_POST['fecha'];
    $horas = $_POST['horas'];
    $descripcion = $_POST['descripcion'];

    $stmt = $conn->prepare("INSERT INTO timesheet (id_user, id_project, fecha, horas, descripcion) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisis", $id_user, $id_project, $fecha, $horas, $descripcion);

    if ($stmt->execute()) {
        $mensaje = "<div class='success'>✅ Horas cargadas correctamente. <a href='ver_horas.php'>Ver horas</a></div>";
    } else {
        $mensaje = "<div class='error'>❌ Error: " . $conn->error . "</div>";
    }

    $stmt->close();
}

// Obtener proyectos para el select
$proyectos = $conn->query("SELECT id_project, nombre FROM projects ORDER BY nombre ASC");

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Cargar Horas</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        .card {
            background: white;
            padding: 30px 25px;
            border-radius: 16px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.1);
            max-width: 500px;
            margin: 40px auto;
        }
        .card h2 {
            margin-bottom: 25px;
            text-align: center;
            letter-spacing: 0.5px;
        }
        form label {
            display: block;
            margin-top: 15px;
            font-weight: 500;
        }
        form input, form select, form textarea {
            width: 100%;
            padding: 12px;
            margin-top: 5px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-family: inherit;
            font-size: 14px;
            box-sizing: border-box;
        }
        form button {
            margin-top: 25px;
            padding: 15px;
            width: 100%;
            font-size: 16px;
            letter-spacing: 0.5px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
            text-align: center;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
            text-align: center;
        }
        .volver {
            display: block;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="card">
        <h2>📝 Cargar Horas</h2>

        <?php if($mensaje) echo $mensaje; ?>

        <form method="POST">
            <label>Proyecto:</label>
            <select name="id_project" required>
                <option value="">--Selecciona un proyecto--</option>
                <?php while($row = $proyectos->fetch_assoc()): ?>
                    <option value="<?= $row['id_project'] ?>"><?= htmlspecialchars($row['nombre']) ?></option>
                <?php endwhile; ?>
            </select>

            <label>Fecha:</label>
            <input type="date" name="fecha" required>

            <label>Horas:</label>
            <input type="number" step="0.5" min="0" max="24" name="horas" required>

            <label>Descripción:</label>
            <textarea name="descripcion" rows="3"></textarea>

            <button type="submit">Guardar Horas</button>
        </form>

        <a href="panel.php" class="volver">⬅ Volver al panel</a>
    </div>
</body>
</html>
