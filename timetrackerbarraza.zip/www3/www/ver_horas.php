<?php
session_start();
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "timesheet_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$id_user = $_SESSION['id_user'];
$rol = $_SESSION['rol'];

if ($rol === 'admin') {
    $sql = "SELECT t.fecha, t.horas, t.descripcion, 
                   u.nombre AS usuario, 
                   p.nombre AS proyecto
            FROM timesheet t
            JOIN users u ON t.id_user = u.id_user
            JOIN projects p ON t.id_project = p.id_project
            ORDER BY t.fecha DESC";
} else {
    $sql = "SELECT t.fecha, t.horas, t.descripcion, 
                   p.nombre AS proyecto
            FROM timesheet t
            JOIN projects p ON t.id_project = p.id_project
            WHERE t.id_user = ?
            ORDER BY t.fecha DESC";
}

$stmt = $conn->prepare($sql);

if ($rol !== 'admin') {
    $stmt->bind_param("i", $id_user);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="style.css">

    <meta charset="UTF-8">
    <title>Horas Cargadas</title>
    <style>
        table {
            border-collapse: collapse;
            width: 90%;
            margin: 20px auto;
        }
        th, td {
            border: 1px solid #999;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #ddd;
        }
        h2 {
            text-align: center;
        }
        a {
            display: block;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h2>Horas Cargadas</h2>
    <table>
        <tr>
            <?php if ($rol === 'admin') echo "<th>Usuario</th>"; ?>
            <th>Proyecto</th>
            <th>Fecha</th>
            <th>Horas</th>
            <th>Descripción</th>
        </tr>

        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <?php if ($rol === 'admin') echo "<td>{$row['usuario']}</td>"; ?>
                <td><?= htmlspecialchars($row['proyecto']) ?></td>
                <td><?= htmlspecialchars($row['fecha']) ?></td>
                <td><?= htmlspecialchars($row['horas']) ?></td>
                <td><?= htmlspecialchars($row['descripcion']) ?></td>
            </tr>
        <?php } ?>
    </table>

    <a href="panel.php">⬅ Volver al panel</a>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
