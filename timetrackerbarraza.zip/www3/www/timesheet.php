<?php
// timesheet.php
session_start();
if (!isset($_SESSION['id_user'])) {
    header('Location: login.php');
    exit;
}
require_once 'conexion.php';

$userId = (int) $_SESSION['id_user'];
$userName = $_SESSION['nombre'] ?? 'Usuario';

// cargar proyectos activos
$projects = [];
$pstmt = $mysqli->prepare("SELECT id_project, nombre FROM projects WHERE estado = 'activo' ORDER BY nombre");
$pstmt->execute();
$pres = $pstmt->get_result();
$projects = $pres->fetch_all(MYSQLI_ASSOC);

// cargar entradas del usuario
$entries = [];
$estmt = $mysqli->prepare("SELECT t.id_timesheet, t.id_project, t.fecha, t.horas, t.descripcion, p.nombre AS project_name
                           FROM timesheet t
                           LEFT JOIN projects p ON p.id_project = t.id_project
                           WHERE t.id_user = ?
                           ORDER BY t.fecha DESC, t.id_timesheet DESC");
$estmt->bind_param('i', $userId);
$estmt->execute();
$eres = $estmt->get_result();
$entries = $eres->fetch_all(MYSQLI_ASSOC);

// cerrar conexiones sencillas
$pstmt->close();
$estmt->close();
?>
<!doctype html>
<html lang="es">
<head>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Timesheet - Panel</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
  <style>
    /* === FONDO DE CÍRCULOS COLORIDOS === */
body {
  position: relative;
  overflow: hidden;
  background: #0f172a;
}

.fondo-circulos {
  position: fixed;
  top: 0; left: 0;
  width: 100%; height: 100%;
  overflow: hidden;
  z-index: -1;
}
.circulo {
  position: absolute;
  border-radius: 50%;
  opacity: 0.3;
  animation: moverCirculo 25s linear infinite;
}
@keyframes moverCirculo {
  0% { transform: translateY(0) rotate(0deg); }
  100% { transform: translateY(-2000px) rotate(720deg); }
}

    /* Copiar estilos del diseño colorido (reducido para brevedad) */
    :root{
      --muted:#9aa4b2; --accent-1:#7C3AED; --accent-2:#06B6D4;
    }
    *{box-sizing:border-box} body{font-family:Inter,system-ui,Arial;background:linear-gradient(180deg,#071025,#07202c);color:#e6eef6;margin:0;padding:28px;display:flex;justify-content:center}
    .container{max-width:1200px;width:100%;display:grid;grid-template-columns:320px 1fr;gap:24px}
    .sidebar{background:rgba(255,255,255,0.02);padding:18px;border-radius:12px}
    .main{background:rgba(255,255,255,0.02);padding:18px;border-radius:12px;min-height:600px}
    .logo{width:48px;height:48px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(135deg,var(--accent-1),var(--accent-2));font-weight:800}
    .btn{padding:10px 12px;border-radius:10px;border:none;cursor:pointer;font-weight:700}
    .btn.primary{background:linear-gradient(90deg,var(--accent-1),var(--accent-2));color:white}
    .row{display:grid;grid-template-columns:1fr 120px 120px 100px;gap:12px;align-items:center;padding:10px;border-radius:10px;background:rgba(255,255,255,0.01);margin-bottom:8px}
    .pill{padding:6px 8px;border-radius:999px}
    .project-pill{background:linear-gradient(90deg,var(--accent-1),var(--accent-2));color:white;font-weight:700}
    .modal-backdrop{position:fixed;inset:0;background:rgba(2,6,23,0.6);display:none;align-items:center;justify-content:center}
    .modal{background:#061226;padding:18px;border-radius:10px;width:100%;max-width:720px}
    input, select, textarea{width:100%;padding:10px;border-radius:8px;border:1px solid rgba(255,255,255,0.04);background:transparent;color:inherit}
    footer{color:var(--muted);font-size:13px;margin-top:10px}
    @media (max-width:980px){ .container{grid-template-columns:1fr} .sidebar{order:2} .main{order:1} .row{grid-template-columns:1fr 1fr} }
  </style>
</head>
<body>
<div class="fondo-circulos">
  <div class="circulo" style="width:300px;height:300px;background:#7C3AED;left:10%;animation-delay:0s;"></div>
  <div class="circulo" style="width:400px;height:400px;background:#06B6D4;left:60%;animation-delay:5s;"></div>
  <div class="circulo" style="width:250px;height:250px;background:#F97316;left:80%;animation-delay:10s;"></div>
  <div class="circulo" style="width:350px;height:350px;background:#10B981;left:50%;animation-delay:7s;"></div>
  <div class="circulo" style="width:350px;height:350px;background:#10B981;left:15%;animation-delay:2s;"></div>
  <div class="circulo" style="width:350px;height:350px;background:#10B981;left:20%;animation-delay:9s;"></div>
</div>

  <div class="container">
    <aside class="sidebar">
      <div style="display:flex;gap:12px;align-items:center;margin-bottom:12px">
        <div class="logo">TS</div>
        <div>
          <div style="font-weight:800">Timesheet</div>
          <div style="color:var(--muted);font-size:13px">Hola, <?=htmlspecialchars($userName)?> · <small style="color:var(--muted)">sesión activa</small></div>
        </div>
      </div>

      <div style="margin-bottom:12px">
        <label style="color:var(--muted);font-size:13px">Filtrar proyecto</label>
        <select id="filterProject">
          <option value="">— Todos —</option>
          <?php foreach($projects as $p): ?>
            <option value="<?= (int)$p['id_project'] ?>"><?= htmlspecialchars($p['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div style="margin-bottom:12px">
        <label style="color:var(--muted);font-size:13px">Buscar</label>
        <input id="filterSearch" placeholder="descripcion, proyecto..." />
      </div>

      <div style="display:flex;gap:10px;margin-top:10px">
        <button id="openAdd" class="btn primary">+ Cargar hora</button>
        <form method="post" action="logout.php" style="display:inline;">
          <button class="btn" style="background:transparent;border:1px solid rgba(255,255,255,0.04)">Cerrar</button>
        </form>
      </div>
      <form action="logout.php" method="post" style="margin-top:10px;">
  <button class="btn" style="background:transparent;border:1px solid rgba(255,255,255,0.1);color:#f87171">
    🔒 Cerrar sesión
  </button>
</form>


      <div style="margin-top:18px;color:var(--muted);font-size:13px">
        <strong>Consejos:</strong>
        <ul>
          <li>Click en editar para modificar una entrada.</li>
          <li>Los cambios se guardan en la base de datos.</li>
        </ul>
      </div>
    </aside>

    <main class="main">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
        <div>
          <h2 style="margin:0">Registro de horas</h2>
          <div style="color:var(--muted)">Panel personal</div>
        </div>
        <div style="text-align:right">
          <div style="color:var(--muted);font-size:13px">Total acumulado</div>
          <div id="totalHours" style="font-weight:800">0h</div>
          

        </div>
      </div>

      <section id="entriesContainer">
        <!-- Filas renderizadas por JS -->
      </section>

      <footer>
        Timesheet · conectado a MySQL · Usuario: <?=htmlspecialchars($userName)?>
      </footer>
    </main>
  </div>

  <!-- Modal -->
  <div class="modal-backdrop" id="modal">
    <div class="modal">
      <h3 id="modalTitle">Cargar horas</h3>
      <div style="margin-top:8px">
        <label>Proyecto</label>
        <select id="inputProject">
          <option value="0">-- Seleccionar --</option>
          <?php foreach($projects as $p): ?>
            <option value="<?= (int)$p['id_project'] ?>"><?= htmlspecialchars($p['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
        <div style="margin-top:8px;font-size:13px;color:var(--muted)">
          Si querés crear un <strong>nuevo proyecto</strong>, escribí su nombre abajo y déjalo en blanco aquí.
        </div>
        <input id="inputNewProject" placeholder="Nombre nuevo proyecto (opcional)" style="margin-top:8px"/>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px">
        <div>
          <label>Fecha</label>
          <input id="inputDate" type="date" />
        </div>
        <div>
          <label>Horas</label>
          <input id="inputHours" type="number" step="0.25" min="0" value="1" />
        </div>
      </div>

      <div style="margin-top:8px">
        <label>Descripción</label>
        <textarea id="inputDesc" rows="3"></textarea>
      </div>

      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px">
        <button id="cancelModal" class="btn">Cancelar</button>
        <button id="saveEntry" class="btn primary">Guardar</button>
      </div>
    </div>
  </div>

<script>
  // Datos iniciales (inyectados desde servidor)
  const initialEntries = <?= json_encode($entries, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
  const initialProjects = <?= json_encode($projects, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
  let entries = initialEntries.slice();
  let projects = initialProjects.slice();

  // DOM
  const container = document.getElementById('entriesContainer');
  const totalHoursEl = document.getElementById('totalHours');
  const filterProject = document.getElementById('filterProject');
  const filterSearch = document.getElementById('filterSearch');

  const modal = document.getElementById('modal');
  const modalTitle = document.getElementById('modalTitle');
  const inputProject = document.getElementById('inputProject');
  const inputNewProject = document.getElementById('inputNewProject');
  const inputDate = document.getElementById('inputDate');
  const inputHours = document.getElementById('inputHours');
  const inputDesc = document.getElementById('inputDesc');
  const saveEntryBtn = document.getElementById('saveEntry');
  const cancelModalBtn = document.getElementById('cancelModal');
  const openAddBtn = document.getElementById('openAdd');

  let editingId = null;

  function formatHours(h) {
    return parseFloat(h).toFixed(2).replace('.00','') + 'h';
  }

  function render() {
    const fp = filterProject.value;
    const q = filterSearch.value.trim().toLowerCase();
    let filtered = entries.filter(e => {
      if (fp && String(e.id_project) !== String(fp)) return false;
      if (q) {
        const hay = (e.descripcion||'').toLowerCase() + ' ' + (e.project_name||'').toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
    container.innerHTML = '';
    filtered.forEach(e => {
      const row = document.createElement('div');
      row.className = 'row';
      row.innerHTML = `
        <div>
          <div style="display:flex;gap:10px;align-items:center">
            <div class="pill project-pill">${escapeHtml(e.project_name || 'Sin proyecto')}</div>
            <div style="font-weight:700">${escapeHtml(e.descripcion || '')}</div>
          </div>
          <small style="color:${'#9aa4b2'}">${escapeHtml(e.fecha)}</small>
        </div>
        <div style="text-align:right"><div class="pill">${escapeHtml(e.horas)}</div></div>
        <div><small>${escapeHtml(e.id_project ? 'Proyecto' : '')}</small></div>
        <div style="text-align:right">
          <button class="btn" onclick="editEntry(${e.id_timesheet})">Editar</button>
          <button class="btn" onclick="deleteEntry(${e.id_timesheet})">Borrar</button>
        </div>
      `;
      container.appendChild(row);
    });

    const total = entries.reduce((s,it)=> s + parseFloat(it.horas||0), 0);
    totalHoursEl.textContent = formatHours(total);
  }

  function escapeHtml(str) {
    if (str == null) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  // Abrir modal para crear
  openAddBtn.addEventListener('click', () => {
    editingId = null;
    modalTitle.textContent = 'Cargar horas';
    inputProject.value = '0';
    inputNewProject.value = '';
    inputDate.value = new Date().toISOString().slice(0,10);
    inputHours.value = '1';
    inputDesc.value = '';
    modal.style.display = 'flex';
  });
  cancelModalBtn.addEventListener('click', ()=> modal.style.display = 'none');

  saveEntryBtn.addEventListener('click', async () => {
    const project_id = inputProject.value;
    const new_project_name = inputNewProject.value.trim();
    const fecha = inputDate.value || new Date().toISOString().slice(0,10);
    const horas = inputHours.value;
    const descripcion = inputDesc.value.trim();

    const data = new FormData();
    if (editingId) {
      data.append('action','update');
      data.append('id_timesheet', editingId);
      data.append('project_id', project_id);
      data.append('fecha', fecha);
      data.append('horas', horas);
      data.append('descripcion', descripcion);
    } else {
      data.append('action','create');
      data.append('project_id', project_id);
      data.append('new_project_name', new_project_name);
      data.append('fecha', fecha);
      data.append('horas', horas);
      data.append('descripcion', descripcion);
    }

    try {
      const res = await fetch('acciones.php', { method:'POST', body: data });
      const json = await res.json();
      if (!json.ok) return alert('Error: ' + (json.error||'desconocido'));

      if (editingId) {
        // recargar lista via fetch
        await reloadEntries();
        modal.style.display = 'none';
      } else {
        // insertar localmente el entry nuevo (respuesta incluye entry)
        if (json.entry) {
          entries.unshift(json.entry);
        } else {
          await reloadEntries();
        }
        // si se creó proyecto, recargar proyectos
        if (new_project_name) {
          await reloadProjects();
        }
        modal.style.display = 'none';
      }
      render();
    } catch (err) {
      alert('Error de red o servidor');
      console.error(err);
    }
  });

  // editar
  window.editEntry = function(id) {
    const e = entries.find(x => String(x.id_timesheet) === String(id));
    if (!e) return alert('Entrada no encontrada');
    editingId = e.id_timesheet;
    modalTitle.textContent = 'Editar entrada';
    inputProject.value = e.id_project || '0';
    inputNewProject.value = '';
    inputDate.value = e.fecha;
    inputHours.value = e.horas;
    inputDesc.value = e.descripcion;
    modal.style.display = 'flex';
  }

  // borrar
  window.deleteEntry = async function(id) {
    if (!confirm('Borrar esta entrada?')) return;
    const data = new FormData();
    data.append('action','delete');
    data.append('id_timesheet', id);
    try {
      const res = await fetch('acciones.php', { method:'POST', body: data });
      const json = await res.json();
      if (!json.ok) return alert('Error: ' + (json.error||'desconocido'));
      // quitar de entries local
      entries = entries.filter(x => String(x.id_timesheet) !== String(id));
      render();
    } catch (err) {
      alert('Error de red o servidor');
    }
  }

  // recargar entries desde server
  async function reloadEntries() {
    try {
      const res = await fetch('acciones.php?action=fetch_entries');
      const json = await res.json();
      if (json.ok) {
        entries = json.entries;
      } else {
        console.warn('No se pudieron traer entradas', json.error);
      }
    } catch (e) {
      console.error(e);
    }
  }

  // recargar proyectos desde server (por si se crea uno nuevo)
  async function reloadProjects() {
    try {
      const res = await fetch('acciones.php?action=fetch_projects');
      const json = await res.json();
      if (json.ok) {
        projects = json.projects;
        // actualizar select
        inputProject.innerHTML = '<option value="0">-- Seleccionar --</option>';
        filterProject.innerHTML = '<option value="">— Todos —</option>';
        json.projects.forEach(p => {
          const opt = document.createElement('option');
          opt.value = p.id_project;
          opt.textContent = p.nombre;
          inputProject.appendChild(opt);

          const opt2 = document.createElement('option');
          opt2.value = p.id_project;
          opt2.textContent = p.nombre;
          filterProject.appendChild(opt2);
        });
      }
    } catch (e) {
      console.error(e);
    }
  }

  // filtros
  filterProject.addEventListener('change', render);
  filterSearch.addEventListener('input', render);

  // inicial
  render();
  // cerrar modal con ESC
  document.addEventListener('keydown', e => { if (e.key === 'Escape') modal.style.display = 'none'; });
  
</script>
<script>
let chart; // variable global para el gráfico

function generarGrafico() {
  if (!entries.length) return;
  
  // Agrupar horas por proyecto
  const horasPorProyecto = {};
  entries.forEach(e => {
    const nombre = e.project_name || 'Sin proyecto';
    horasPorProyecto[nombre] = (horasPorProyecto[nombre] || 0) + parseFloat(e.horas || 0);
  });

  const labels = Object.keys(horasPorProyecto);
  const data = Object.values(horasPorProyecto);

  // Colores llamativos automáticos
  const colores = labels.map((_, i) => `hsl(${(i*60)%360}, 80%, 55%)`);

  // Si ya existe un gráfico, destruirlo para actualizar
  if (chart) chart.destroy();

  const ctx = document.getElementById('chartProyectos').getContext('2d');
  chart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: labels,
      datasets: [{
        data: data,
        backgroundColor: colores,
        borderColor: 'rgba(255,255,255,0.2)',
        borderWidth: 2,
        hoverOffset: 15
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'bottom',
          labels: { color: '#e6eef6', font: { size: 13 } }
        },
        title: {
          display: false
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const total = data.reduce((a,b)=>a+b,0);
              const valor = context.raw;
              const porcentaje = ((valor / total) * 100).toFixed(1);
              return `${context.label}: ${valor}h (${porcentaje}%)`;
            }
          }
        }
      },
      animation: {
        animateRotate: true,
        duration: 1200,
        easing: 'easeOutQuart'
      },
      cutout: '70%'
    }
  });
}

// Llamar cada vez que se renderiza
const renderOriginal = render;
render = function() {
  renderOriginal(); // llama a la función existente
  generarGrafico(); // actualiza el gráfico
};

// Generar gráfico inicial
generarGrafico();
/* ==== ANIMACIONES Y EFECTOS ==== */
@keyframes fadeSlideUp {
  0% { opacity: 0; transform: translateY(20px); }
  100% { opacity: 1; transform: translateY(0); }
}
@keyframes pulseGlow {
  0%, 100% { box-shadow: 0 0 0 rgba(6,182,212,0.4); }
  50% { box-shadow: 0 0 20px rgba(6,182,212,0.6); }
}

.fade-in { animation: fadeSlideUp 0.6s ease both; }
.card-anim {
  transition: transform 0.25s ease, box-shadow 0.25s ease;
}
.card-anim:hover {
  transform: translateY(-6px);
  box-shadow: 0 10px 25px rgba(6,182,212,0.3);
}
.btn.primary {
  position: relative;
  overflow: hidden;
  z-index: 0;
  transition: transform 0.15s ease;
}
.btn.primary::after {
  content: '';
  position: absolute;
  left: -50%;
  top: 0;
  width: 200%;
  height: 100%;
  background: radial-gradient(circle, rgba(255,255,255,0.25) 0%, transparent 70%);
  transform: translateX(-100%);
  opacity: 0;
  transition: opacity 0.3s ease, transform 0.6s ease;
}
.btn.primary:hover::after {
  transform: translateX(50%);
  opacity: 1;
}
.btn.primary:hover {
  transform: scale(1.05);
}

/* Animación de aparición de filas */
.row {
  animation: fadeSlideUp 0.4s ease both;
  transition: transform 0.2s ease, background 0.2s ease;
}
.row:hover {
  background: rgba(255,255,255,0.06);
  transform: scale(1.02);
}

/* Sombra suave animada al cargar el panel */
.main {
  animation: pulseGlow 2s ease-in-out infinite;
}

</script>
<script>
// Animación suave al cargar contenido
window.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.row').forEach((el, i) => {
    el.style.animationDelay = `${i * 0.05}s`;
    el.classList.add('fade-in');
  });
});

// Efecto de "pulse" al actualizar el total de horas
function animarTotalHoras() {
  const el = document.getElementById('totalHours');
  el.style.transition = 'transform 0.3s ease';
  el.style.transform = 'scale(1.3)';
  setTimeout(() => el.style.transform = 'scale(1)', 300);
}

// Insertar llamada dentro del render original
const renderAntiguo = render;
render = function() {
  renderAntiguo();
  animarTotalHoras();
};
</script>


</body>
</html>
