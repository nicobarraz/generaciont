<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// acciones.php
header('Content-Type: application/json; charset=utf-8');
session_start();
require_once 'conexion.php';

if (!isset($_SESSION['id_user'])) {
    echo json_encode(['ok' => false, 'error' => 'No autenticado']);
    exit;
}

$userId = (int) $_SESSION['id_user'];
$action = $_REQUEST['action'] ?? '';

function json_error($msg) {
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}

switch ($action) {
    case 'fetch_entries':
        // devuelve registros del usuario con nombre de proyecto
        $sql = "SELECT t.id_timesheet, t.id_project, t.fecha, t.horas, t.descripcion, p.nombre AS project_name
                FROM timesheet t
                LEFT JOIN projects p ON p.id_project = t.id_project
                WHERE t.id_user = ?
                ORDER BY t.fecha DESC, t.id_timesheet DESC";
        if ($stmt = $mysqli->prepare($sql)) {
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            $res = $stmt->get_result();
            $rows = $res->fetch_all(MYSQLI_ASSOC);
            echo json_encode(['ok' => true, 'entries' => $rows]);
            exit;
        } else {
            json_error('Error en consulta');
        }
        break;

    case 'fetch_projects':
        // devuelve proyectos activos
        $sql = "SELECT id_project, nombre FROM projects WHERE estado = 'activo' ORDER BY nombre";
        $res = $mysqli->query($sql);
        $rows = $res->fetch_all(MYSQLI_ASSOC);
        echo json_encode(['ok' => true, 'projects' => $rows]);
        exit;
        break;

        case 'create':
            $projectId = isset($_POST['project_id']) ? (int)$_POST['project_id'] : 0;
            $newProject = trim($_POST['new_project_name'] ?? '');
            $fecha = $_POST['fecha'] ?? date('Y-m-d');
            $horas = (float)($_POST['horas'] ?? 0);
            $descripcion = trim($_POST['descripcion'] ?? '');
        
            // Si mandaron un nuevo proyecto, crearlo
            if ($projectId <= 0 && $newProject !== '') {
                $stmtP = $mysqli->prepare("INSERT INTO projects (nombre, descripcion, estado) VALUES (?, '', 'activo')");
                $stmtP->bind_param('s', $newProject);
                if ($stmtP->execute()) {
                    $projectId = $stmtP->insert_id;
                } else {
                    echo json_encode(['ok' => false, 'error' => 'No se pudo crear el proyecto']);
                    exit;
                }
                $stmtP->close();
            }
        
            if ($projectId <= 0) {
                echo json_encode(['ok' => false, 'error' => 'Proyecto inválido']);
                exit;
            }
        
            $stmt = $mysqli->prepare("INSERT INTO timesheet (id_user, id_project, fecha, horas, descripcion) VALUES (?,?,?,?,?)");
            $stmt->bind_param('iisss', $userId, $projectId, $fecha, $horas, $descripcion);
        
            if ($stmt->execute()) {
                echo json_encode(['ok' => true]);
            } else {
                echo json_encode(['ok' => false, 'error' => $stmt->error]);
            }
            exit;
        

    case 'update':
        // campos: id_timesheet, project_id, fecha, horas, descripcion
        $id = isset($_POST['id_timesheet']) ? (int) $_POST['id_timesheet'] : 0;
        $projectId = isset($_POST['project_id']) ? (int) $_POST['project_id'] : 0;
        $fecha = $_POST['fecha'] ?? date('Y-m-d');
        $horas = (float) ($_POST['horas'] ?? 0);
        $descripcion = trim($_POST['descripcion'] ?? '');

        if ($id <= 0) json_error('ID inválido');

        // verificar que la entrada pertenezca al usuario
        $vstmt = $mysqli->prepare("SELECT id_timesheet FROM timesheet WHERE id_timesheet = ? AND id_user = ?");
        $vstmt->bind_param('ii', $id, $userId);
        $vstmt->execute();
        $vres = $vstmt->get_result();
        if ($vres->num_rows === 0) json_error('No autorizado o entrada inexistente');

        $stmt = $mysqli->prepare("UPDATE timesheet SET id_project = ?, fecha = ?, horas = ?, descripcion = ? WHERE id_timesheet = ? AND id_user = ?");
        $stmt->bind_param('isdssi', $projectId, $fecha, $horas, $descripcion, $id, $userId);
        if ($stmt->execute()) {
            echo json_encode(['ok' => true]);
            exit;
        } else {
            json_error('No se pudo actualizar');
        }
        break;

    case 'delete':
        $id = isset($_POST['id_timesheet']) ? (int) $_POST['id_timesheet'] : 0;
        if ($id <= 0) json_error('ID inválido');

        // asegurar pertenencia
        $vstmt = $mysqli->prepare("SELECT id_timesheet FROM timesheet WHERE id_timesheet = ? AND id_user = ?");
        $vstmt->bind_param('ii', $id, $userId);
        $vstmt->execute();
        $vres = $vstmt->get_result();
        if ($vres->num_rows === 0) json_error('No autorizado o entrada inexistente');

        $stmt = $mysqli->prepare("DELETE FROM timesheet WHERE id_timesheet = ? AND id_user = ?");
        $stmt->bind_param('ii', $id, $userId);
        if ($stmt->execute()) {
            echo json_encode(['ok' => true]);
            exit;
        } else {
            json_error('No se pudo borrar');
        }
        break;

    default:
        json_error('Acción inválida');
}
