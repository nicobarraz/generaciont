<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Timesheet - Inicio</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            text-align: center;
            width: 350px;
        }
        h1 {
            font-weight: 600;
            margin-bottom: 20px;
            color: #333;
        }
        p {
            color: #555;
        }
        a {
            display: block;
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            padding: 12px;
            margin: 12px 0;
            border-radius: 8px;
            font-weight: 500;
            transition: background-color 0.3s;
        }
        a:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>📊 Timesheet</h1>
        <p>Bienvenido a la plataforma de carga de horas</p>
        <a href="login.php">Iniciar Sesión</a>
        <a href="registro.php">Registrarse</a>
    </div>
</body>
</html>
