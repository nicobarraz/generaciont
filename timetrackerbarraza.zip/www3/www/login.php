<?php
session_start();
require_once 'conexion.php';

if (isset($_SESSION['id_user'])) {
    header('Location: timesheet.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $stmt = $mysqli->prepare("SELECT id_user, nombre, password FROM users WHERE email = ?");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 1) {
        $user = $res->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['id_user'] = $user['id_user'];
            $_SESSION['nombre'] = $user['nombre'];
            header('Location: timesheet.php');
            exit;
        } else {
            $error = 'Contraseña incorrecta.';
        }
    } else {
        $error = 'Usuario no encontrado.';
    }
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Iniciar sesión - Timesheet</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;500;700&display=swap" rel="stylesheet">
  <style>
    /* === FONDO DINÁMICO GRADIENTE === */
body {
  position: relative;
  overflow: hidden;
}

body::before {
  content: "";
  position: fixed;
  top: 0;
  left: 0;
  width: 200%;
  height: 200%;
  background: linear-gradient(120deg, #7C3AED, #06B6D4, #F97316, #10B981, #3B82F6);
  background-size: 300% 300%;
  animation: moveGradient 18s ease infinite;
  z-index: -1;
  filter: blur(60px);
  opacity: 0.35;
}

@keyframes moveGradient {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}

    body {
      font-family: Inter, sans-serif;
      background: linear-gradient(135deg,#1e293b,#0f172a);
      color: #f8fafc;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
    }
    .login-box {
      background: rgba(255,255,255,0.05);
      padding: 32px;
      border-radius: 16px;
      width: 100%;
      max-width: 400px;
      backdrop-filter: blur(8px);
      box-shadow: 0 0 25px rgba(0,0,0,0.4);
    }
    h2 { text-align: center; margin-bottom: 24px; }
    input {
      width: 100%;
      padding: 10px;
      margin-bottom: 12px;
      border-radius: 8px;
      border: none;
      background: rgba(255,255,255,0.1);
      color: white;
    }
    button {
      width: 100%;
      padding: 10px;
      border: none;
      border-radius: 8px;
      background: linear-gradient(90deg,#7C3AED,#06B6D4);
      color: white;
      font-weight: bold;
      cursor: pointer;
    }
    .error { background: rgba(239,68,68,0.2); color: #fecaca; padding:8px; border-radius:8px; text-align:center; margin-bottom:10px; }
    .link { text-align:center;margin-top:12px;color:#93c5fd;font-size:14px; }
    a { color:#06b6d4; text-decoration:none; }
  </style>
</head>
<body>
  <form class="login-box" method="post">
    <h2>Iniciar sesión</h2>
    <?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <input type="email" name="email" placeholder="Correo electrónico" required>
    <input type="password" name="password" placeholder="Contraseña" required>
    <button type="submit">Ingresar</button>
    <div class="link">¿No tenés cuenta? <a href="register.php">Registrate</a></div>
  </form>
</body>
</html>
