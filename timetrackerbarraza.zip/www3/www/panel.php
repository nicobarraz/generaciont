<?php
session_start();
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php");
    exit;
}

$nombre = $_SESSION['nombre'];
$rol = $_SESSION['rol'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Usuario</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <style>
        /* Barra de navegación */
        .navbar {
            background-color: #4CAF50;
            padding: 15px 25px;
            border-radius: 12px 12px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            font-size: 16px;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            margin-left: 25px; /* más espacio entre links */
            font-weight: 500;
            letter-spacing: 0.5px; /* un poco más de separación de letras */
        }
        .navbar a:hover {
            text-decoration: underline;
        }

        /* Contenido del panel */
        .panel-content {
            padding: 30px 20px;
            text-align: center;
        }
        .panel-content h2 {
            margin-bottom: 25px;
            letter-spacing: 0.5px;
        }
        .panel-content a.btn {
            display: block;
            margin: 20px auto; /* más espacio arriba y abajo */
            padding: 15px 20px; /* botones más grandes y cómodos */
            width: 70%; /* ancho uniforme */
            font-size: 16px;
            letter-spacing: 0.5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="navbar">
            <div>Hola, <?= htmlspecialchars($nombre) ?> (<?= htmlspecialchars($rol) ?>)</div>
            <div>
                <a href="ver_horas.php">Ver Horas</a>
                <a href="cargar_horas.php">Cargar Horas</a>
                <a href="logout.php">Cerrar Sesión</a>
            </div>
        </div>

        <div class="panel-content">
            <h2>Panel de Control</h2>
            <a href="cargar_horas.php" class="btn">📝 Cargar Horas</a>
            <a href="ver_horas.php" class="btn">📊 Ver Horas</a>
            <?php if($rol === 'admin'): ?>
                <a href="admin_proyectos.php" class="btn">⚙️ Administrar Proyectos</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
