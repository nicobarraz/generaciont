<?php
// conexion.php
// Configuración de conexión (ajustar si es necesario)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "timesheet_db";

// Crear conexión
$mysqli = new mysqli($servername, $username, $password, $dbname);
if ($mysqli->connect_errno) {
    http_response_code(500);
    die("Error de conexión MySQL: " . $mysqli->connect_error);
}
$mysqli->set_charset("utf8mb4");
