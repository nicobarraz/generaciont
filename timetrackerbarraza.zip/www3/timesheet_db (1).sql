-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 10-11-2025 a las 15:00:46
-- Versión del servidor: 8.0.31
-- Versión de PHP: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `timesheet_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE IF NOT EXISTS `projects` (
  `id_project` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text,
  `estado` enum('activo','inactivo') DEFAULT 'activo',
  PRIMARY KEY (`id_project`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `projects`
--

INSERT INTO `projects` (`id_project`, `nombre`, `descripcion`, `estado`) VALUES
(1, 'Proyecto A', 'Desarrollo de nueva web corporativa', 'activo'),
(2, 'Proyecto B', 'Migración de base de datos a MySQL', 'activo'),
(3, 'Proyecto C', 'Capacitación interna de empleados', 'activo'),
(4, 'proyecto barri', 'barrii', 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `timesheet`
--

DROP TABLE IF EXISTS `timesheet`;
CREATE TABLE IF NOT EXISTS `timesheet` (
  `id_timesheet` int NOT NULL AUTO_INCREMENT,
  `id_user` int NOT NULL,
  `id_project` int NOT NULL,
  `fecha` date NOT NULL,
  `horas` decimal(4,2) NOT NULL,
  `descripcion` text,
  PRIMARY KEY (`id_timesheet`),
  KEY `id_user` (`id_user`),
  KEY `id_project` (`id_project`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `timesheet`
--

INSERT INTO `timesheet` (`id_timesheet`, `id_user`, `id_project`, `fecha`, `horas`, `descripcion`) VALUES
(1, 1, 1, '2025-03-21', '5.00', 'hola uwu'),
(2, 1, 1, '2025-09-23', '4.50', 'Diseño de landing page'),
(3, 1, 2, '2025-09-23', '3.00', 'Configuración de servidor'),
(4, 2, 3, '2025-09-22', '6.00', 'Preparación de material de capacitación'),
(5, 1, 1, '2025-09-18', '1.00', 'k'),
(6, 1, 1, '2025-09-04', '1.00', 'aa'),
(7, 4, 1, '2025-09-05', '1.00', '2'),
(8, 6, 4, '2025-09-12', '2.00', 'aaaaa'),
(9, 3, 1, '2025-11-10', '1.00', 'aaaaa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id_user` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `rol` enum('empleado','admin') DEFAULT 'empleado',
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id_user`, `nombre`, `email`, `password`, `rol`) VALUES
(1, 'Juan Pérez', 'juan@example.com', '1234', 'empleado'),
(2, 'Ana López', 'ana@example.com', '1234', 'admin'),
(3, 'Carlos Admin', 'admin@example.com', '1234', 'admin'),
(10, 'holauwu', 'a@gmail.com', '$2y$10$Oy7zBZCexUxRQlVYo0DkxOKFi1POz53C88MziP9ksfmYOgU.cwAJW', 'admin'),
(6, 'wwww', 'admin@gmail.com', '$2y$10$Hjz6DuosnGBhhgfpVjYKxez1Rr7v62ul7M4DVC6Cn6PQrw1A/uSKy', 'admin');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
